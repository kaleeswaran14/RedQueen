if (window['google'] != undefined && window['google']['loader'] != undefined) {
if (!window['google']['visualization']) {
window['google']['visualization'] = {};
google.visualization.Version = '1.0';
google.visualization.JSHash = '38ac42a54ac1c4d5dedb5677b2e06487';
google.visualization.LoadArgs = 'file\75visualization\46v\0751\46packages\75geochart';
}
google.loader.writeLoadTag("script", google.loader.ServiceBase + "/api/visualization/1.0/38ac42a54ac1c4d5dedb5677b2e06487/format+en,default,geochart.I.js", false);
}
