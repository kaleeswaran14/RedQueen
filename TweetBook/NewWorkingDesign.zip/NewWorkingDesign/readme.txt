<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/combine_fonts.css">
<link rel="stylesheet" href="css/datepicker.css">
<link rel="stylesheet" href="css/colorpicker.css">
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css">
<link rel="stylesheet" href="css/jquery.plupload.queue.css">
<link rel="stylesheet" href="css/buttons.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/dark.css">
<link rel="stylesheet" href="css/cms.css">
<link rel="stylesheet" href="css/bootstrap-responsive.css">
<link href="img/favicon.ico" rel="shortcut icon">

<link href="../assets/ico/apple-touch-icon-144-precomposed.png" sizes="144x144" rel="apple-touch-icon-precomposed">
<link href="../assets/ico/apple-touch-icon-114-precomposed.png" sizes="114x114" rel="apple-touch-icon-precomposed">
<link href="../assets/ico/apple-touch-icon-72-precomposed.png" sizes="72x72" rel="apple-touch-icon-precomposed">
<link href="../assets/ico/apple-touch-icon-57-precomposed.png" rel="apple-touch-icon-precomposed">

<script type="text/javascript" src="js/countries_en.js">


<script src="js/jsapi.js">
<script src="js/jquery.js">
<script src="js/wysihtml5-0.3.0_rc3.min.js">
<script src="js/bootstrap.js">
<script src="js/bootstrap-datepicker.js">
<script src="js/bootstrap-colorpicker.js">
<script src="js/bootstrap-wysihtml5.js">
<script src="js/browserplus-min.js" type="text/javascript">
<script src="js/plupload.full.js" type="text/javascript">
<script src="js/jquery.plupload.queue.js" type="text/javascript">
<script src="js/demo.js">
<script src="js/google-chart-index.js">
<script type="text/javascript" src="js/geoChartVisualization.js">
<script type="text/javascript" src="js/formatendefaultgeochart.js">




/./////////////////
  <!-- <script src="countries_en.js" type="text/javascript"></script> -->
<!-- <link rel="stylesheet" type="text/css" href="index.css" media="all"> -->

<!--<script type="text/javascript" src="js/countries_en.js">-->