var xmlHttp;
var resultDiv;
var loadingObj;
var textFieldId;
var refreshPath;

function createXMLHttpRequest() {

    if (window.ActiveXObject) {

        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else if (window.XMLHttpRequest) {

        xmlHttp = new XMLHttpRequest();
    }
}

function pushDataWithLoading(pathURL, resultDivName, loading) {
    loadingObj = loading;
    resultDiv = resultDivName;
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleStateChange;
    xmlHttp.open("POST", pathURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttp.send(null);
}

function callRestService(pathURL) {
    createXMLHttpRequest();
    xmlHttp.open("POST", pathURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttp.send(null);
}

function pushData(formName, pathURL, resultDivName) {
    resultDiv = resultDivName;
    //var pathURL = parent.window.document.getElementById(pathURL);
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleStateChange;
    xmlHttp.open("POST", pathURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var queryString = getFormValues(formName);

    xmlHttp.send(queryString);
}

function handleStateChange() {

    if(xmlHttp.readyState == 4) {
        
        var messageDivObject = null;
        if(xmlHttp.status == 200) {
            
            messageDivObject = window.document.getElementById(resultDiv);
            if(messageDivObject == null) {
                messageDivObject = parent.window.document.getElementById(resultDiv);
            }
            if(messageDivObject.style.display == "none") {
                messageDivObject.style.display = '';
            }
            
            messageDivObject.innerHTML = xmlHttp.responseText;
        } else {

            var errorHTML = '<font color="red">' + xmlHttp.statusText + '</font>';
            messageDivObject = window.document.getElementById(resultDiv);
            if(messageDivObject == null) {
                messageDivObject = parent.window.document.getElementById(resultDiv);
            }
            messageDivObject.innerHTML = errorHTML;
        }

        if (loadingObj != null && loadingObj != "undefined") {
            loadingObj.style.display = 'none';
        }
    }
}

function pushDataAndRefresh(formName, pathURL, resultDivName, path) {
    resultDiv = resultDivName;
    refreshPath = path;
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleRefreshStateChange;
    xmlHttp.open("POST", pathURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var queryString = getFormValues(formName);

    xmlHttp.send(queryString);
}

function handleRefreshStateChange() {

    if(xmlHttp.readyState == 4) {

        if(xmlHttp.status == 200) {
            top.window.location.href = refreshPath;
        } else {

            var errorHTML = '<font color="red">' + xmlHttp.statusText + '</font>';
            messageDivObject = window.document.getElementById(resultDiv);
            if(messageDivObject == null) {
                messageDivObject = parent.window.document.getElementById(resultDiv);
            }
            messageDivObject.innerHTML = errorHTML;
        }

        if (loadingObj != null && loadingObj != "undefined") {
            loadingObj.style.display = 'none';
        }
    }
}

function generateData(formName, pathURL, resultDivName, textField) {
    resultDiv = resultDivName;
    textFieldId = textField;
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleGenerateStateChange;
    xmlHttp.open("POST", pathURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var queryString = getFormValues(formName);

    xmlHttp.send(queryString);
}

function handleGenerateStateChange() {

    if(xmlHttp.readyState == 4) {
        
        var messageDivObject = null;

        if(xmlHttp.status == 200) {
            var textFieldObj = window.document.getElementById(textFieldId);
            textFieldObj.value = xmlHttp.responseText;
        } else {

            var errorHTML = '<font color="red">' + xmlHttp.statusText + '</font>';
            messageDivObject = window.document.getElementById(resultDiv);
            if(messageDivObject == null) {
                messageDivObject = parent.window.document.getElementById(resultDiv);
            }
            messageDivObject.innerHTML = errorHTML;
        }

        if (loadingObj != null && loadingObj != "undefined") {
            loadingObj.style.display = 'none';
        }
    }
}

function ajxCall(formName, pathURL, resultDivName) {
    resultDiv = resultDivName;
    //var pathURL = parent.window.document.getElementById(pathURL);
    createXMLHttpRequest();
    xmlHttp.onreadystatechange = handleAJXStateChange;
    xmlHttp.open("POST", pathURL, true);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var queryString = getFormValues(formName);

    xmlHttp.send(queryString);
}

function handleAJXStateChange() {

    if(xmlHttp.readyState == 4) {
        
        var messageDivObject = null;
        if(xmlHttp.status == 200) {
            
            messageDivObject = window.document.getElementById(resultDiv);
            if(messageDivObject == null) {
                messageDivObject = parent.window.document.getElementById(resultDiv);
            }
            if(messageDivObject.style.display == "none") {
                messageDivObject.style.display = '';
            }
            
            messageDivObject.innerHTML = xmlHttp.responseText;
            
            var buttonObj = window.document.getElementById("enableButton");
            //alert(xmlHttp.responseText);

            if (buttonObj != null && buttonObj != "undefined") {
                buttonObj.disabled = false;
            }

        } else {

            var errorHTML = '<font color="red">' + xmlHttp.statusText + '</font>';
            messageDivObject = window.document.getElementById(resultDiv);
            if(messageDivObject == null) {
                messageDivObject = parent.window.document.getElementById(resultDiv);
            }
            messageDivObject.innerHTML = errorHTML;
        }

        if (loadingObj != null && loadingObj != "undefined") {
            loadingObj.style.display = 'none';
        }
    }
}

function getFormValues(formName) {

    var str = "";
    var valueArr = null;
    var val = "";
    var cmd = "";
    var formObj = null;
    formObj = window.document.getElementById(formName);
    if(formObj == null) {
    
        formObj = parent.window.document.getElementById(formName);
    }
    if(formObj) {
        try {
            for(var i = 0; i < formObj.elements.length; i++) {

                switch(formObj.elements[i].type) {

                    case "text":
                        str += formObj.elements[i].name + "=" + escape(formObj.elements[i].value) + "&";
                    break;

                    case "textarea":
                        str += formObj.elements[i].name + "=" + escape(formObj.elements[i].value) + "&";
                    break;

                    case "password":    
                        str += formObj.elements[i].name + "=" + escape(formObj.elements[i].value) + "&";
                    break;

                    case "hidden":    
                        str += formObj.elements[i].name + "=" + escape(formObj.elements[i].value) + "&";
                    break;

                    case "checkbox":
                        str += formObj.elements[i].name + "=" + escape(formObj.elements[i].checked) + "&";
                    break;

                    case "select-one":
                        str += formObj.elements[i].name + "=" + formObj.elements[i].options[formObj.elements[i].selectedIndex].value + "&";
                    break;

                    case "select-multiple":
                        var multiSelectLength = formObj.elements[i].length;
                        for(var j = 0; j < multiSelectLength; j++) {

                            if(formObj.elements[i].options[j].selected) {

                                str += formObj.elements[i].name + "=" + formObj.elements[i].options[j].value + "&";
                            }
                        }
                    break;
                }
            }
        } catch(ex) {
        }
    }

    str = str.substr(0,(str.length - 1));

    return str;
}